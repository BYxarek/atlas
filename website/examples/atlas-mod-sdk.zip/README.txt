ATLAS mod examples / Примеры модов

Use Godot 4.8-beta2 standard edition. No .NET or extra libraries.
Из корня SDK / From the SDK root:
godot --headless --path . --script tools/build_mod.gd -- examples/starter-economy dist/starter-economy.atlasmod
Replace starter-economy with fast-operations or naval-campaign for the other examples.
The three legacy examples contain complete balances; Frontier uses portable API 2 content.
Balance tests: python tools/test_mod_balance.py --godot PATH_TO_GODOT --config balance-plan.json --output report.json dist/frontier.atlasmod
Три прежних примера содержат полный баланс; Frontier использует переносимый контент API 2.
Install the output .atlasmod using the Mods menu in a matching development game build.
