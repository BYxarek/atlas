ATLAS mod examples / Примеры модов

Use Godot 4.8-beta2 standard edition. No .NET or extra libraries.
Из корня SDK / From the SDK root:
godot --headless --path . --script tools/build_mod.gd -- examples/starter-economy dist/starter-economy.atlasmod
Replace starter-economy with fast-operations or naval-campaign for the other examples.
Each example contains a COMPLETE balance object. Later mods replace it in full.
Каждый пример содержит ПОЛНЫЙ баланс; последний мод заменяет его целиком.
Install the output .atlasmod using the Mods menu in a matching development game build.
